print("Python di drive D berfungsi dengan baik!")
